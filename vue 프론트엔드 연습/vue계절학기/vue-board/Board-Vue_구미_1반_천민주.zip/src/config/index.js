const API_BASE_URL = "http://localhost:8000/board";

export { API_BASE_URL };
