<template>
  <div>
    <navi />
    회원가입페이지입니다.
  </div>
</template>

<script>
import Navi from "@/components/common/Navi";

export default {
  name: "join",
  components: {
    Navi
  }
};
</script>

<style></style>
