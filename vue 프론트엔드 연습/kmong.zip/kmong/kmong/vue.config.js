module.exports = {
  transpileDependencies: ["vuetify"]
};
